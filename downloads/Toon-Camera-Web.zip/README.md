# Toon Camera

A browser and desktop camera filter that replaces your head with an original **adult Asian woman avatar**: dark layered hair, brown eyes, natural lips and an optional simple teal neckline. Your own body and clothing receive adjustable cel shading. Facial movement drives the avatar's expression in real time.

The current app replaces the game entry point. The previous Sonic page and documentation remain in `sonic.html` and `README-SONIC.md`.

## Use the app

On **Windows 10/11 (64-bit)**, download and run **`dist/windows/Toon-Camera-Windows-x64.exe`**. This portable app bundles Chromium, the filter and all tracking models. It needs no Python, Node, browser installation or model download. Click **Enable camera** to begin; Windows camera privacy settings must allow desktop apps. Saved photos and clips use a Save dialog. The executable is unsigned. Windows execution has not been tested in this Linux environment; the Electron wrapper was exercised on Linux with a camera fixture.

Open **`dist/Toon-Camera.html`** in a current desktop browser, click **Enable camera**, and allow camera access. This file includes the tracking runtimes, models, artwork and styles; it makes no external asset or inference requests. Some browsers restrict camera access or WASM in local files. In that case, use the hosted version.

For phones, extract **`dist/Toon-Camera-Web.zip`** to any HTTPS static web host and open its address in the phone's browser. No application install, account, server-side inference, extension, headset or external camera is required. Your device needs its usual camera. Camera access requires HTTPS or localhost; an ordinary HTTP LAN address is insufficient. A static-host package is provided, but this repository does not automatically publish to a hosting service.

- **Photo:** tap the shutter, then Save or Share.
- **Video:** select Video, tap to start and again to stop. Clips stop automatically after 60 seconds. The output format is selected from the browser's supported MP4/WebM codecs.
- **Record sound:** optional; microphone permission is requested only when recording with this setting enabled.
- **Flip:** switches the requested front/rear camera. A device with only one camera may keep the same camera.
- **Mirror:** toggles the preview and exported image together.
- **Cartoon body:** adjusts shading strength without changing your body or clothes into a costume.
- **Avatar neckline:** toggles the tracked teal crew-neck.
- **Framing:** portrait 720×1280 or landscape 1280×720; locked during recording.
- **Camera off:** stops its media tracks. Hiding the page also turns the camera off.

Captures are held in memory until saved/shared, replaced or the page closes. Sharing uses the browser's own share sheet where file sharing is supported; Save is always available. There is no automatic upload or cloud gallery.

## Tracking and rendering

MediaPipe Face Mesh detects up to 478 face/iris landmarks locally. Landmark geometry drives position, scale, roll, approximate yaw, left/right blinking, eyebrow elevation, mouth opening, smile and eye direction. The Canvas vector character is continuously redrawn with those controls. It is an original rigged character drawing, not a fixed sticker or a generative-video face replacement.

MediaPipe Selfie Segmentation isolates the camera subject over a violet backdrop. A WebGL shader applies edge ink, luminance bands and color styling to the body. The renderer suppresses the original head region and adds the character's dark hair, neckline and expressive face. The very same canvas supplies photos and recordings.

The tracking input is capped at 640 pixels wide, face inference is scheduled at up to 20 updates per second, foreground inference runs every third update, and rendering targets 30 fps. These are scheduling caps, not guaranteed device performance. Smooth follow and fast blink response use different interpolation rates. The non-SIMD WASM runtimes are retained as fallbacks.

## Practical limits

Best results come from front lighting, one visible face and frontal/moderate head turns. This is a 2D character rig with approximate head-turn deformation, not a complete 3D head model. Full profiles, large hats, fast occlusions, fingers across the face and hair outside the replacement region may expose seams or lose tracking. There is no hand-occlusion mesh. When tracking is lost, the head fades away and the app asks you to face the camera. Body segmentation can have soft edges around hair and clothing. The app does not replace the user's full body with an avatar outfit.

Chromium is exercised with a real local camera fixture and actual MediaPipe inference. Physical iOS/Android camera testing and all browser-specific codec combinations are not claimed. The managed test browser blocks all `file://` navigation by policy, so the self-contained HTML was verified over localhost with every secondary network request blocked; local-file camera access was not verified in this environment. Browsers without WebGL show the camera body without the GPU cartoon pass; video capture availability depends on MediaRecorder and canvas capture support.

## Develop

The runtime has no npm install or build requirement. All third-party runtime files are already under `filter/vendor/`.

```sh
python3 tools/filter/serve.py --port 8010
```

Open the app from the server in your development browser. The server sends appropriate WASM content types and restricts camera/microphone use to the same origin. Production browser hosting needs HTTPS.

To develop the desktop app, run `npm ci`, then `npm start`. Build the portable Windows executable with `npm run dist:win`. Electron serves the bundled assets from a secure local `app://camera` origin, allows camera/microphone only for that origin, and blocks external renderer network requests. The renderer runs sandboxed without Node access.

In this managed Linux environment, use writable download caches:

```sh
npm ci --ignore-scripts --cache /tmp/charmcaster-npm-cache
ELECTRON_BUILDER_CACHE=/tmp/charmcaster-builder-cache npm run dist:win -- --config.electronDownload.cache=/tmp/charmcaster-electron-cache
```

The build produces `dist/windows/Toon-Camera-Windows-x64.exe`. For native Linux smoke testing, first install the development Electron binary with `ELECTRON_GET_USE_PROXY=true electron_config_cache=/tmp/charmcaster-electron-cache node node_modules/electron/install.js`, then run `tests/filter/desktop.cjs` with the same fixture and `NODE_PATH` used below. Set `ELECTRON_HEADLESS=1` in a Linux environment without a display. These are development dependencies only.

Rebuild both browser distributions:

```sh
python3 tools/filter/build.py
```

This embeds the JS, CSS and binary models into the standalone HTML, resolves model asset requests through local Blob URLs, and creates a static-host ZIP. Model SHA-256 hashes are recorded under `filter/vendor/SHA256SUMS.json`.

## Validation

Install the test tools outside the repository:

```sh
npm install --prefix /tmp/charmcaster-test --no-audit --no-fund playwright-core@1.56.1
```

Generate the checksum-verified, public-domain camera fixture with `python3 tools/filter/prepare_test.py` (requires FFmpeg, development only), then run:

```sh
CAMERA_FIXTURE=/tmp/charmcaster-test/camera.y4m \
NODE_PATH=/tmp/charmcaster-test/node_modules \
node tests/filter/smoke.cjs
```

`APP_URL` selects the source, standalone HTTP URL or standalone file URL. The test uses Chromium at `/usr/bin/chromium` unless `CHROMIUM_PATH` is provided. It exercises real face/foreground inference, expression measurements, visible iris drawing, photo export, playable video capture, settings, camera release, mobile layout, permission denial and absence of external requests. Test-only inspection is exposed only with `?test`.

## Files

- `filter/character.js`: original vector artwork and expression rig.
- `filter/tracking.js`: local face/foreground inference and landmark measurements.
- `filter/render.js`: GPU cartoon body filter and layered compositing.
- `filter/app.js`: camera lifecycle, controls, capture, recording and sharing.
- `filter/style.css`: responsive camera UI.
- `filter/vendor/`: pinned local MediaPipe runtimes/models and license.
- `tools/filter/build.py`: self-contained HTML and static-host packaging.
- `tools/filter/serve.py`: local development server.

Asset and license details are in [filter/ASSETS.md](filter/ASSETS.md).
