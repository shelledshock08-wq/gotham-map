# Assets and provenance

## Character

The avatar is an original adult East Asian woman with dark layered hair, brown eyes, a warm natural skin palette and an optional teal crew-neck. `character.js` contains editable Canvas vector artwork with continuous expression controls. It is not based on a real person's likeness. No photographs, television frames or character artwork are bundled.

## Tracking and segmentation

Locally vendored npm distributions:

- `@mediapipe/face_mesh` **0.4.1633559619** — Google MediaPipe, Apache-2.0. Includes face detection/landmark models in the packed asset bundle and SIMD/non-SIMD WASM runtimes.
- `@mediapipe/selfie_segmentation` **0.1.1675465747** — Google MediaPipe, Apache-2.0. Includes selfie segmentation TFLite models and WASM runtimes.

Source project: https://github.com/google-ai-edge/mediapipe
Package registries: https://www.npmjs.com/package/@mediapipe/face_mesh and https://www.npmjs.com/package/@mediapipe/selfie_segmentation

The Apache-2.0 license is preserved at `vendor/LICENSE-APACHE-2.0.txt`; original package metadata is retained. `vendor/SHA256SUMS.json` records hashes. Runtime requests resolve only to included files or embedded Blob URLs. Google-hosted Face Landmarker downloads were unavailable in this environment, so this implementation uses the complete, locally available Face Mesh distribution instead; there is no dependency on the newer Face Landmarker service or a remote fallback.

## Other

UI icons, backgrounds, circular studio graphics and the body-shading GLSL shader are original code. System fonts are used; no font downloads occur.

Browser tests use a local Y4M camera fixture generated from scikit-image's NASA astronaut sample (Eileen Collins, public-domain NASA photograph), fetched from the scikit-image v0.19.3 test-data tree. The portrait/fixture is a development tool and is not included in the app or its distributions. No camera images are shipped as user examples or sent to external services.
