/* Original adult East Asian woman avatar. Continuous Canvas expression rig. */
"use strict";
window.CharmCharacter = (() => {
  const ink = "#241d24",
    skin = "#e4b394",
    shade = "#ca927c";
  const hair = "#24232d",
    hairLight = "#403a49",
    iris = "#70482e";
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  function path(g, d, fill, stroke = ink, width = 0.025) {
    const p = new Path2D(d);
    if (fill) {
      g.fillStyle = fill;
      g.fill(p);
    }
    if (stroke) {
      g.strokeStyle = stroke;
      g.lineWidth = width;
      g.lineJoin = "round";
      g.lineCap = "round";
      g.stroke(p);
    }
  }
  function transform(g, h) {
    g.translate(h.x, h.y);
    g.rotate(h.roll || 0);
    g.scale(h.sx, h.sy);
  }
  function back(g, h, t = 0) {
    g.save();
    transform(g, h);
    g.translate(Math.sin(t * 1.4) * 0.025 + (h.yaw || 0) * 0.07, 0);
    path(
      g,
      "M -.97 -.54 Q -1.08 -1.66 .02 -1.67 Q 1.12 -1.67 1.05 -.45 L 1.12 1.11 Q 1.14 1.85 1.38 2.27 Q .76 2.55 .26 2.25 L -.13 2.23 Q -.73 2.55 -1.28 2.18 Q -1.02 1.77 -1.07 1.02 Z",
      hair,
      ink,
      0.035,
    );
    path(
      g,
      "M -.83 -.55 Q -.94 .69 -.85 1.35 Q -.8 2.01 -1.06 2.2 L -.66 2.29 Q -.59 1.8 -.66 1.2 L -.63 -.62 Z",
      hairLight,
      null,
    );
    path(
      g,
      "M .88 -.57 Q .8 .8 .94 1.5 Q 1.01 1.97 1.16 2.24 L .83 2.29 Q .6 1.54 .64 .64 Z",
      "#33303e",
      null,
    );
    path(
      g,
      "M -.94 .47 Q -.99 1.48 -.87 1.94 M 1 .5 Q .94 1.41 1.12 1.96",
      null,
      "#57505c",
      0.012,
    );
    g.restore();
  }
  function collar(g, h) {
    g.save();
    transform(g, h);
    path(
      g,
      "M -.32 .74 L -.32 1.36 Q -.66 1.46 -.98 1.65 L -1.12 2.13 Q 0 2.41 1.13 2.13 L .99 1.65 Q .61 1.43 .34 1.35 L .34 .74 Z",
      skin,
    );
    path(
      g,
      "M -.31 .91 Q 0 1.25 .34 .89 L .34 1.22 Q .03 1.47 -.32 1.18 Z",
      shade,
      null,
    );
    path(
      g,
      "M -.97 1.64 L -.45 1.42 Q -.35 1.79 .03 1.79 Q .39 1.79 .46 1.42 L .99 1.65 Q 1.17 1.83 1.23 2.23 Q 0 2.53 -1.22 2.23 Q -1.16 1.83 -.97 1.64 Z",
      "#407e80",
      ink,
      0.03,
    );
    path(
      g,
      "M -.45 1.43 Q -.36 1.79 .03 1.79 Q .39 1.79 .46 1.43",
      null,
      "#80b3ae",
      0.065,
    );
    path(
      g,
      "M -.91 1.85 L -.98 2.25 M .94 1.87 L 1.01 2.25",
      null,
      "#2a5b62",
      0.025,
    );
    g.restore();
  }
  function eye(g, side, e, yaw) {
    const open = clamp(1 - (side < 0 ? e.blinkL : e.blinkR)),
      brow = side < 0 ? e.browL : e.browR;
    g.save();
    g.translate(side * 0.39 + yaw * 0.045, -0.19);
    g.scale(side * yaw > 0 ? 1 - Math.abs(yaw) * 0.2 : 1, 1);
    const top = -0.11 * open,
      bottom = 0.105 * open;
    const outline = `M -.29 .015 Q -.12 ${top - 0.04} .035 ${top} Q .18 ${top} .29 -.005 Q .14 ${bottom + 0.025} -.025 ${bottom} Q -.18 ${bottom} -.29 .015 Z`;
    if (open < 0.09) path(g, "M -.28 .015 Q 0 .09 .28 -.005", null, ink, 0.025);
    else {
      path(g, outline, "#fff4e9", ink, 0.023);
      g.save();
      g.clip(new Path2D(outline));
      const gx = (e.gazeX || 0) * 0.08,
        gy = (e.gazeY || 0) * 0.04 - 0.005;
      g.fillStyle = iris;
      g.beginPath();
      g.ellipse(gx, gy, 0.12, 0.145, 0, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = "#3b2a26";
      g.lineWidth = 0.016;
      g.stroke();
      g.fillStyle = "#211d20";
      g.beginPath();
      g.ellipse(gx, gy, 0.055, 0.079, 0, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "#fff9ee";
      g.beginPath();
      g.ellipse(gx - 0.035, gy - 0.047, 0.024, 0.029, 0, 0, Math.PI * 2);
      g.fill();
      g.restore();
      path(
        g,
        `M -.29 .015 Q -.12 ${top - 0.04} .035 ${top} Q .18 ${top} .29 -.005`,
        null,
        ink,
        0.031,
      );
      path(
        g,
        side < 0 ? "M -.29 .015 L -.33 -.018" : "M .29 -.005 L .33 -.036",
        null,
        ink,
        0.02,
      );
    }
    g.translate(0, -0.25 - brow * 0.13);
    path(
      g,
      side < 0
        ? "M -.28 .045 Q -.04 -.05 .26 .03 L .25 .065 Q -.05 -.005 -.28 .073 Z"
        : "M -.26 .03 Q .04 -.05 .28 .045 L .28 .073 Q .05 -.005 -.25 .065 Z",
      "#39303a",
      null,
    );
    g.restore();
  }
  function head(g, h, expression = {}) {
    const e = {
      blinkL: 0,
      blinkR: 0,
      browL: 0,
      browR: 0,
      jaw: 0,
      smile: 0.2,
      gazeX: 0,
      gazeY: 0,
      ...expression,
    };
    const yaw = clamp(h.yaw || 0, -0.8, 0.8),
      jaw = clamp(e.jaw),
      smile = clamp(e.smile),
      chin = 1.02 + jaw * 0.1;
    g.save();
    transform(g, h);
    path(g, "M -.79 -.25 Q -1.05 -.39 -1.03 -.06 Q -1 .2 -.83 .24 Z", skin);
    path(g, "M .8 -.25 Q 1.04 -.39 1.03 -.06 Q 1 .2 .84 .24 Z", skin);
    path(
      g,
      `M -.84 -.68 Q -.7 -1.17 .02 -1.19 Q .73 -1.17 .85 -.65 L .84 .22 Q .77 .7 .3 ${chin - 0.08} Q .03 ${chin + 0.13} -.24 ${chin - 0.055} Q -.76 .74 -.85 .22 Z`,
      skin,
      ink,
      0.03,
    );
    path(
      g,
      `M .68 -.8 Q .89 -.44 .84 .22 Q .77 .7 .3 ${chin - 0.08} Q .04 ${chin + 0.13} -.24 ${chin - 0.055} Q .09 .99 .35 .78 Q .75 .42 .68 -.8 Z`,
      shade,
      null,
    );
    g.fillStyle = "rgba(199,111,108,.18)";
    for (const side of [-1, 1]) {
      g.beginPath();
      g.ellipse(side * 0.57, 0.28, 0.17, 0.075, 0, 0, Math.PI * 2);
      g.fill();
    }
    eye(g, -1, e, yaw);
    eye(g, 1, e, yaw);
    const nose = yaw * 0.27;
    path(
      g,
      `M ${nose + 0.005} .08 Q ${nose + 0.025} .24 ${nose - 0.055} .3 Q ${nose - 0.025} .35 ${nose + 0.055} .34`,
      null,
      "#a37164",
      0.017,
    );
    path(
      g,
      `M ${nose - 0.1} .345 Q ${nose - 0.08} .325 ${nose - 0.055} .34 M ${nose + 0.075} .34 Q ${nose + 0.105} .32 ${nose + 0.125} .34`,
      null,
      "#a37164",
      0.012,
    );
    const w = 0.21 + smile * 0.07,
      top = 0.57 - smile * 0.045,
      bottom = top + 0.025 + jaw * 0.33 + smile * 0.065;
    g.save();
    g.translate(yaw * 0.1, 0);
    path(
      g,
      `M ${-w} ${top} Q -.06 ${top - 0.055} 0 ${top - 0.018} Q .09 ${top - 0.055} ${w} ${top} Q .14 ${bottom + 0.06} 0 ${bottom + 0.07} Q -.15 ${bottom + 0.06} ${-w} ${top} Z`,
      "#ba7274",
      null,
    );
    if (jaw > 0.08 || smile > 0.4) {
      const mouth = `M ${-w + 0.025} ${top + 0.015} Q 0 ${top + 0.055} ${w - 0.025} ${top + 0.015} Q .13 ${bottom} 0 ${bottom + 0.02} Q -.14 ${bottom} ${-w + 0.025} ${top + 0.015} Z`;
      path(g, mouth, "#502c35", null);
      g.save();
      g.clip(new Path2D(mouth));
      path(
        g,
        `M ${-w} ${top} L ${w} ${top} L ${w} ${top + 0.08} Q 0 ${top + 0.13} ${-w} ${top + 0.08} Z`,
        "#fff4e9",
        null,
      );
      if (jaw > 0.45)
        path(
          g,
          `M -.14 ${bottom} Q 0 ${bottom - 0.09} .14 ${bottom} Z`,
          "#d58a91",
          null,
        );
      g.restore();
    } else
      path(
        g,
        `M ${-w} ${top + 0.015} Q 0 ${top + 0.065} ${w} ${top + 0.015}`,
        null,
        "#8a5056",
        0.014,
      );
    g.restore();
    // Soft side-parted dark hair with curved layers and quiet highlights.
    path(
      g,
      "M -.86 .02 Q -1.13 -.56 -.93 -1.11 Q -.71 -1.68 .02 -1.65 Q .81 -1.66 1.03 -1.08 Q 1.17 -.52 .86 .18 L .78 -.51 Q .68 -.89 .28 -1.07 Q -.05 -.77 -.38 -.63 Q -.68 -.46 -.86 .02 Z",
      hair,
      ink,
      0.035,
    );
    path(
      g,
      "M .17 -1.5 Q -.43 -1.52 -.76 -1.08 Q -.94 -.81 -.89 -.43 Q -.81 -.85 -.47 -1.03 Q -.09 -1.17 .17 -1.5 Z",
      hairLight,
      null,
    );
    path(
      g,
      "M .28 -1.49 Q .78 -1.48 .97 -.98 Q 1.02 -.74 .97 -.44 Q .84 -1.1 .28 -1.49 Z",
      "#383440",
      null,
    );
    path(g, "M .25 -1.51 Q .21 -1.23 .28 -1.07", null, "#62515a", 0.015);
    path(
      g,
      "M -.88 -.49 Q -.86 .1 -.79 .46 Q -.76 .85 -.54 1.27 Q -.92 1.06 -1 .49 Q -1.1 -.06 -.99 -.69 Z",
      hair,
      ink,
      0.025,
    );
    path(g, "M -.94 -.36 Q -.97 .47 -.72 .95", null, "#59505d", 0.018);
    path(
      g,
      "M .85 -.59 Q .96 -.29 .92 .2 Q .85 .82 .63 1.26 Q 1.06 1.01 1.07 .37 Q 1.16 -.23 1.01 -.78 Z",
      hair,
      ink,
      0.025,
    );
    path(g, "M 1 -.28 Q 1.02 .43 .85 .84", null, "#514855", 0.017);
    g.restore();
  }
  function preview(w, h, t = 0) {
    return {
      x: w * 0.49,
      y: h * 0.34,
      sx: Math.min(w * 0.29, h * 0.18),
      sy: Math.min(w * 0.29, h * 0.18),
      roll: Math.sin(t * 0.55) * 0.045,
      yaw: Math.sin(t * 0.4) * 0.12,
    };
  }
  return {
    back,
    collar,
    head,
    preview,
    palette: { ink, skin, shade, hair, hairLight, iris },
  };
})();
